name = 'isaac'

print(name)
print('name')
print('I have a friend named ' + name)

