x=10
y=2
z=5
result = x + y + z
print(f" {x} + {y} + {z} = {result}")