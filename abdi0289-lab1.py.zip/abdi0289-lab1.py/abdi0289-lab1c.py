num1 = 5
num2 = 10

print(num1)
print(num2)

sum = num1 + num2
print(sum)

print('The sum is: ' + str(sum))
