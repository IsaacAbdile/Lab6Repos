#!/bin/python3
print()
print ('hello world')

#!/usr/bin/env python3




